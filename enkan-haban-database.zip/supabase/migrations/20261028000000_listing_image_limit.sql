-- ---------------------------------------------------------------------------
-- ክሳብ 10 ስእልታት ኣብ ሓደ ንብረት / At most 10 photos per listing
-- sort_order 0..9 + the existing unique (listing_id, sort_order) = max 10 rows
-- per listing, enforced by the database even if two uploads race.
-- Matches MAX_PHOTOS = 10 in the app (shared/.../ui/sell/PhotoPicker.kt).
-- ---------------------------------------------------------------------------
alter table public.listing_images
  add constraint listing_images_max_10
  check (sort_order between 0 and 9);

comment on constraint listing_images_max_10 on public.listing_images is
  'ክሳብ 10 ስእልታት ኣብ ሓደ ንብረት / max 10 photos per listing (sort_order 0 = cover)';
