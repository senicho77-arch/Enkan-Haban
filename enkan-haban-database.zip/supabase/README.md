# እንካን ሃባን — ዳታበይዝ (Supabase / PostgreSQL)

## ኣብዚ ዘሎ
| ፋይል | እንታይ ይገብር |
|---|---|
| `migrations/20261027000000_init_marketplace.sql` | 14 ሰሌዳታት, ፍተሻ (search), ትእዛዝ (place_order), ዕላል, ውሕስነት (RLS) |
| `migrations/20261027000100_storage.sql` | ስእልታት ንብረት ዝቕመጣሉ ቦታ (`listing-images`) |
| `migrations/20261027000200_reference_data.sql` | ባጤራታት (UGX, ETB, ERN, USD, EUR…) ን ምድብታት ብትግርኛን እንግሊዝኛን |

## ሰሌዳታት (tables)
- **profiles** — ተጠቀምቲ (ብ Google ምስ ኣተዉ ባዕሉ ይፍጠር)
- **stores** — ድኳናት · **categories** — ምድብታት (ti/en)
- **listings** — ንብረት (store = ብዘንቢል ዝዕደግ, classified = መወዓውዒ) · **listing_images**
- **cart_items** — ዘንቢል · **orders / order_items** — ትእዛዛት
- **favorites** · **conversations / messages** — ዕላል ዓዳግን ሻያጥን
- **reviews** — ርእይቶ ሻያጢ · **reports** — ጸብጻብ ምትላል
- **currencies** — ባጤራታት

## ከመይ ትጥቀመሉ
1. ኣብ https://supabase.com ሓድሽ project ክፈት።
2. **Authentication → Providers → Google** ኣበርክቶ (Google Client ID/Secret ካብ Google Cloud)።
3. **SQL Editor** ክፈት፣ ነቶም ሰለስተ ፋይላት ብቕደም ስዕቦም (000000 → 000100 → 000200) ለጢፍካ **Run** በል።
   ወይ ብ Supabase CLI: `supabase link` ድሕሪኡ `supabase db push`።

## ውሕስነት (ዝተፈተነ)
- ሓደ ተጠቀምቲ ናይ ካልእ ሰብ ንብረት ክቕይር ወይ ክድምስስ ኣይክእልን።
- ዓዳጊ ዋጋ ትእዛዝ ክቕይር ኣይክእልን — ዋጋ ካብ ዳታበይዝ ይንበብ (`place_order`)።
- ዘንቢል ንድኳን ንብረት ጥራይ; መወዓውዒ (classified) ብዕላል ወይ ብቴሌፎን።
- `is_verified` / `is_official` ብኣድሚን ጥራይ ይቕየሩ።
- ዕላል ክልቲኦም ተሳተፍቲ ጥራይ ይርእይዎ።

ዋጋታት ብ "minor units" እዮም (ከም `Product.price` ኣብ ኣፕ)፥ USD 12.50 = `1250`, UGX 45,000 = `45000`.
